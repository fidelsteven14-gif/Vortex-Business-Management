/* ============================================================
   VORTEX BUSINESS MANAGEMENT SYSTEM
   GitHub Pages / frontend-only demonstration
   ============================================================
   IMPORTANT:
   This demo stores data in localStorage so it can run on GitHub
   Pages without a backend. Do not use this authentication model
   for real production data. Replace it with Supabase Auth/DB
   before onboarding real businesses.
   ============================================================ */

"use strict";

const STORAGE_KEY = "vortex_business_management_full_v1";

const App = {
  db: null,
  page: "dashboard",
  scanner: null,
  scannerRunning: false,
  lastReceipt: null,
  toastTimer: null
};

function uid(prefix = "ID") {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function nowISO() {
  return new Date().toISOString();
}

function money(value) {
  return `KES ${Number(value || 0).toLocaleString("en-KE", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

function saveDB() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(App.db));
}

function loadDB() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    App.db = raw ? JSON.parse(raw) : null;
  } catch (error) {
    console.error(error);
    App.db = null;
  }
}

function freshDatabase() {
  return {
    business: null,
    branches: [],
    products: [],
    customers: [],
    suppliers: [],
    employees: [],
    sales: [],
    transfers: [],
    purchases: [],
    expenses: [],
    activity: [],
    cart: []
  };
}

function toast(message, type = "success") {
  clearTimeout(App.toastTimer);
  let old = document.getElementById("toast");
  if (old) old.remove();

  const el = document.createElement("div");
  el.id = "toast";
  el.className = `notice ${type}`;
  el.style.position = "fixed";
  el.style.right = "18px";
  el.style.bottom = "18px";
  el.style.zIndex = "200";
  el.style.maxWidth = "360px";
  el.textContent = message;
  document.body.appendChild(el);

  App.toastTimer = setTimeout(() => el.remove(), 3500);
}

function addActivity(text) {
  App.db.activity.push({
    id: uid("ACT"),
    text,
    at: nowISO()
  });
}

function getBranchName(branchId) {
  const b = App.db.branches.find(x => x.id === branchId);
  return b ? b.name : "Unknown branch";
}

function render() {
  loadDB();
  if (App.db && App.db.business) {
    renderApplication();
  } else {
    renderAuth();
  }
}

/* =========================
   AUTHENTICATION
   ========================= */

function renderAuth(mode = "login") {
  document.getElementById("app").innerHTML = `
    <div class="auth-page">
      <div class="auth-card">
        <div class="logo">Vortex Business Management System</div>
        <p class="subtitle">
          Business management, inventory, sales, branches, scanning and reporting.
        </p>

        <div class="tabs">
          <button id="loginTab" class="${mode === "login" ? "active" : ""}"
            onclick="showAuth('login')">Log in</button>
          <button id="registerTab" class="${mode === "register" ? "active" : ""}"
            onclick="showAuth('register')">Create business</button>
        </div>

        <div id="authContent"></div>
      </div>
    </div>
  `;

  showAuth(mode);
}

function showAuth(mode) {
  const content = document.getElementById("authContent");
  if (!content) return;

  document.getElementById("loginTab")?.classList.toggle("active", mode === "login");
  document.getElementById("registerTab")?.classList.toggle("active", mode === "register");

  if (mode === "login") {
    content.innerHTML = `
      <form onsubmit="loginBusiness(event)">
        <div class="field">
          <label>Shop / Business Name</label>
          <input id="loginShop" required autocomplete="organization">
        </div>

        <div class="field">
          <label>Password</label>
          <div class="password-row">
            <input id="loginPassword" type="password" required autocomplete="current-password">
            <button type="button" onclick="togglePassword('loginPassword', this)">Show</button>
          </div>
        </div>

        <button class="btn full" type="submit">Log in</button>
      </form>

      <div class="notice">
        This GitHub Pages version is a testing prototype. Your test account
        is stored only in this browser.
      </div>
    `;
  } else {
    content.innerHTML = `
      <form onsubmit="registerBusiness(event)">
        <div class="field">
          <label>Shop / Business Name</label>
          <input id="registerShop" required maxlength="100" autocomplete="organization">
        </div>

        <div class="field">
          <label>Owner Name</label>
          <input id="registerOwner" required maxlength="100" autocomplete="name">
        </div>

        <div class="field">
          <label>Phone Number</label>
          <input id="registerPhone" required maxlength="30" autocomplete="tel">
        </div>

        <div class="field">
          <label>Password</label>
          <div class="password-row">
            <input id="registerPassword" type="password" minlength="6" required autocomplete="new-password">
            <button type="button" onclick="togglePassword('registerPassword', this)">Show</button>
          </div>
        </div>

        <div class="field">
          <label>Confirm Password</label>
          <div class="password-row">
            <input id="registerConfirm" type="password" minlength="6" required autocomplete="new-password">
            <button type="button" onclick="togglePassword('registerConfirm', this)">Show</button>
          </div>
        </div>

        <div class="field">
          <label>
            <input id="terms" type="checkbox" required>
            I agree to use this testing system according to the terms.
          </label>
        </div>

        <button class="btn full" type="submit">Create Business Account</button>
      </form>
    `;
  }
}

function togglePassword(id, button) {
  const input = document.getElementById(id);
  if (!input) return;
  if (input.type === "password") {
    input.type = "text";
    button.textContent = "Hide";
  } else {
    input.type = "password";
    button.textContent = "Show";
  }
}

function registerBusiness(event) {
  event.preventDefault();

  const shop = document.getElementById("registerShop").value.trim();
  const owner = document.getElementById("registerOwner").value.trim();
  const phone = document.getElementById("registerPhone").value.trim();
  const password = document.getElementById("registerPassword").value;
  const confirm = document.getElementById("registerConfirm").value;

  if (password !== confirm) {
    toast("Password and confirm password do not match.", "error");
    return;
  }

  if (password.length < 6) {
    toast("Password must contain at least 6 characters.", "error");
    return;
  }

  const db = freshDatabase();

  db.business = {
    id: uid("BUS"),
    shopName: shop,
    ownerName: owner,
    phone,
    password,
    createdAt: nowISO()
  };

  const mainBranch = {
    id: uid("BR"),
    name: "Main Branch",
    phone,
    address: "",
    createdAt: nowISO()
  };

  db.branches.push(mainBranch);

  addActivityToDB(db, "Business account created");

  App.db = db;
  saveDB();
  toast("Business account created successfully.");
  renderApplication();
}

function addActivityToDB(db, text) {
  db.activity.push({
    id: uid("ACT"),
    text,
    at: nowISO()
  });
}

function loginBusiness(event) {
  event.preventDefault();

  loadDB();

  if (!App.db || !App.db.business) {
    toast("No business account exists in this browser. Create one first.", "error");
    return;
  }

  const shop = document.getElementById("loginShop").value.trim().toLowerCase();
  const password = document.getElementById("loginPassword").value;

  const correctShop = App.db.business.shopName.toLowerCase() === shop;
  const correctPassword = App.db.business.password === password;

  if (!correctShop || !correctPassword) {
    toast("Incorrect shop name or password.", "error");
    return;
  }

  toast("Login successful.");
  renderApplication();
}

function logout() {
  stopScanner();
  App.db = null;
  App.page = "dashboard";
  App.lastReceipt = null;
  localStorage.removeItem(STORAGE_KEY);
  render();
}

/* =========================
   MAIN APPLICATION
   ========================= */

function renderApplication() {
  const b = App.db.business;

  document.getElementById("app").innerHTML = `
    <div class="app-shell">
      <header class="topbar no-print">
        <div class="brand-wrap">
          <div class="brand-mark">V</div>
          <div>
            <div class="brand-title">Vortex Business Management System</div>
            <div class="brand-shop">${escapeHTML(b.shopName)}</div>
          </div>
        </div>

        <div class="top-actions">
          <span class="muted">${escapeHTML(b.ownerName)}</span>
          <button class="btn secondary" onclick="logout()">Log out</button>
        </div>
      </header>

      <div class="layout">
        <aside class="sidebar no-print">
          <div class="nav-label">Business</div>
          ${navButton("dashboard","Dashboard")}
          ${navButton("pos","Sales / POS")}
          ${navButton("scanner","Barcode / QR Scanner")}
          ${navButton("products","Products & Stock")}
          ${navButton("customers","Customers")}
          ${navButton("suppliers","Suppliers")}
          ${navButton("purchases","Purchases / New Stock")}
          ${navButton("transfers","Stock Transfers")}
          ${navButton("expenses","Expenses")}
          ${navButton("branches","Branches")}
          ${navButton("employees","Employees")}

          <div class="nav-label">Reports</div>
          ${navButton("reports","Reports & Printing")}
          ${navButton("activity","Activity Log")}
        </aside>

        <main class="main" id="mainContent">
          ${pageHTML()}
        </main>
      </div>
    </div>
  `;
}

function navButton(page, label) {
  return `
    <button class="nav-btn ${App.page === page ? "active" : ""}"
      onclick="navigate('${page}')">${label}</button>
  `;
}

function navigate(page) {
  stopScanner();
  App.page = page;
  App.lastReceipt = null;
  renderApplication();
}

/* =========================
   DASHBOARD
   ========================= */

function pageHTML() {
  switch (App.page) {
    case "pos": return posPage();
    case "scanner": return scannerPage();
    case "products": return productsPage();
    case "customers": return customersPage();
    case "suppliers": return suppliersPage();
    case "purchases": return purchasesPage();
    case "transfers": return transfersPage();
    case "expenses": return expensesPage();
    case "branches": return branchesPage();
    case "employees": return employeesPage();
    case "reports": return reportsPage();
    case "activity": return activityPage();
    default: return dashboardPage();
  }
}

function dashboardPage() {
  const d = App.db;

  const revenue = d.sales.reduce((sum, sale) => sum + sale.total, 0);
  const stockUnits = d.products.reduce((sum, p) => sum + Number(p.quantity), 0);
  const stockValue = d.products.reduce((sum, p) => sum + Number(p.quantity) * Number(p.buyPrice), 0);
  const lowStock = d.products.filter(p => Number(p.quantity) <= Number(p.minimumStock)).length;
  const deadStock = calculateDeadStock().length;

  return `
    <div class="page-head">
      <div>
        <h1>Dashboard</h1>
        <div class="muted">Overview of ${escapeHTML(d.business.shopName)}</div>
      </div>
      <button class="btn" onclick="navigate('pos')">New Sale</button>
    </div>

    <div class="grid">
      ${metricCard("Products", d.products.length)}
      ${metricCard("Stock Units", stockUnits)}
      ${metricCard("Sales", d.sales.length)}
      ${metricCard("Revenue", money(revenue))}
      ${metricCard("Stock Value", money(stockValue))}
      ${metricCard("Low Stock", lowStock)}
      ${metricCard("Dead Stock", deadStock)}
      ${metricCard("Branches", d.branches.length)}
    </div>

    <div class="two-col" style="margin-top:15px">
      <div class="card">
        <h3>Quick Actions</h3>
        <div class="toolbar">
          <button class="btn" onclick="navigate('scanner')">Scan Product</button>
          <button class="btn secondary" onclick="navigate('products')">Add Product</button>
          <button class="btn secondary" onclick="navigate('purchases')">Record New Stock</button>
          <button class="btn secondary" onclick="navigate('reports')">Reports</button>
        </div>
      </div>

      <div class="card">
        <h3>Recent Activity</h3>
        ${recentActivityHTML(5)}
      </div>
    </div>
  `;
}

function metricCard(label, value) {
  return `
    <div class="card">
      <div class="metric-label">${label}</div>
      <div class="metric-value">${value}</div>
    </div>
  `;
}

function recentActivityHTML(limit = 5) {
  const rows = App.db.activity.slice().reverse().slice(0, limit);

  if (!rows.length) return `<div class="empty">No activity recorded yet.</div>`;

  return rows.map(a => `
    <div class="cart-row">
      <span>${escapeHTML(a.text)}</span>
      <small class="muted">${new Date(a.at).toLocaleString()}</small>
    </div>
  `).join("");
}

/* =========================
   PRODUCTS / INVENTORY
   ========================= */

function productsPage() {
  const products = App.db.products;

  return `
    <div class="page-head">
      <div>
        <h1>Products & Stock</h1>
        <div class="muted">Manage inventory and product identifiers.</div>
      </div>
      <button class="btn" onclick="openProductModal()">Add Product</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Barcode / QR</th>
            <th>Buying Price</th>
            <th>Selling Price</th>
            <th>Quantity</th>
            <th>Minimum</th>
            <th>Branch</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${products.length ? products.map(productRow).join("") :
            `<tr><td colspan="9"><div class="empty">No products yet.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function productRow(p) {
  let status = `<span class="badge green">Normal</span>`;
  if (p.quantity <= 0) status = `<span class="badge red">Out of stock</span>`;
  else if (p.quantity <= p.minimumStock) status = `<span class="badge orange">Low stock</span>`;

  return `
    <tr>
      <td><strong>${escapeHTML(p.name)}</strong><br><small class="muted">${escapeHTML(p.sku || "")}</small></td>
      <td>${escapeHTML(p.code)}</td>
      <td>${money(p.buyPrice)}</td>
      <td>${money(p.sellPrice)}</td>
      <td>${p.quantity}</td>
      <td>${p.minimumStock}</td>
      <td>${escapeHTML(getBranchName(p.branchId))}</td>
      <td>${status}</td>
      <td>
        <button class="btn small secondary" onclick="addStock('${p.id}')">Add Stock</button>
        <button class="btn small" onclick="editProduct('${p.id}')">Edit</button>
      </td>
    </tr>
  `;
}

function openProductModal(productId = null) {
  const p = productId ? App.db.products.find(x => x.id === productId) : null;

  openModal(`
    <div class="modal-head">
      <h2>${p ? "Edit Product" : "Add Product"}</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="${p ? `saveProduct(event,'${p.id}')` : "createProduct(event)"}">
      <div class="field">
        <label>Product Name</label>
        <input id="productName" required value="${escapeHTML(p?.name || "")}">
      </div>

      <div class="field">
        <label>Barcode / QR Identifier</label>
        <input id="productCode" required value="${escapeHTML(p?.code || "")}">
      </div>

      <div class="field">
        <label>SKU</label>
        <input id="productSku" value="${escapeHTML(p?.sku || "")}">
      </div>

      <div class="two-col">
        <div class="field">
          <label>Buying Price</label>
          <input id="productBuy" type="number" min="0" step="0.01" required value="${p?.buyPrice ?? 0}">
        </div>

        <div class="field">
          <label>Selling Price</label>
          <input id="productSell" type="number" min="0" step="0.01" required value="${p?.sellPrice ?? 0}">
        </div>
      </div>

      ${!p ? `
      <div class="two-col">
        <div class="field">
          <label>Opening Quantity</label>
          <input id="productQty" type="number" min="0" required value="0">
        </div>
      ` : `
      <div class="two-col">
        <div class="field">
          <label>Current Quantity</label>
          <input value="${p.quantity}" disabled>
        </div>
      `}

        <div class="field">
          <label>Minimum Stock Alert</label>
          <input id="productMin" type="number" min="0" required value="${p?.minimumStock ?? 5}">
        </div>
      </div>

      <div class="field">
        <label>Branch</label>
        <select id="productBranch" required>
          ${App.db.branches.map(b => `
            <option value="${b.id}" ${p?.branchId === b.id ? "selected" : ""}>
              ${escapeHTML(b.name)}
            </option>
          `).join("")}
        </select>
      </div>

      <button class="btn full" type="submit">${p ? "Save Changes" : "Create Product"}</button>
    </form>
  `);
}

function createProduct(event) {
  event.preventDefault();

  const code = document.getElementById("productCode").value.trim();

  if (App.db.products.some(p => p.code.toLowerCase() === code.toLowerCase())) {
    toast("That barcode or QR identifier already exists.", "error");
    return;
  }

  const product = {
    id: uid("PRD"),
    name: document.getElementById("productName").value.trim(),
    code,
    sku: document.getElementById("productSku").value.trim(),
    buyPrice: Number(document.getElementById("productBuy").value),
    sellPrice: Number(document.getElementById("productSell").value),
    quantity: Number(document.getElementById("productQty").value),
    minimumStock: Number(document.getElementById("productMin").value),
    branchId: document.getElementById("productBranch").value,
    createdAt: nowISO(),
    lastStockInAt: nowISO(),
    lastSoldAt: null
  };

  App.db.products.push(product);
  addActivity(`Product created: ${product.name}`);
  saveDB();
  closeModal();
  toast("Product created successfully.");
  renderApplication();
}

function saveProduct(event, id) {
  event.preventDefault();

  const p = App.db.products.find(x => x.id === id);
  if (!p) return;

  const code = document.getElementById("productCode").value.trim();
  const duplicate = App.db.products.find(x =>
    x.id !== id && x.code.toLowerCase() === code.toLowerCase()
  );

  if (duplicate) {
    toast("Another product already uses that barcode/QR identifier.", "error");
    return;
  }

  p.name = document.getElementById("productName").value.trim();
  p.code = code;
  p.sku = document.getElementById("productSku").value.trim();
  p.buyPrice = Number(document.getElementById("productBuy").value);
  p.sellPrice = Number(document.getElementById("productSell").value);
  p.minimumStock = Number(document.getElementById("productMin").value);
  p.branchId = document.getElementById("productBranch").value;

  addActivity(`Product updated: ${p.name}`);
  saveDB();
  closeModal();
  toast("Product updated.");
  renderApplication();
}

function editProduct(id) {
  openProductModal(id);
}

function addStock(id) {
  const p = App.db.products.find(x => x.id === id);
  if (!p) return;

  openModal(`
    <div class="modal-head">
      <h2>Add New Stock</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <div class="notice">
      Product: <strong>${escapeHTML(p.name)}</strong><br>
      Current stock: ${p.quantity}
    </div>

    <form onsubmit="saveAddedStock(event,'${p.id}')">
      <div class="field">
        <label>Quantity received</label>
        <input id="stockQuantity" type="number" min="1" required>
      </div>

      <div class="field">
        <label>Supplier</label>
        <select id="stockSupplier">
          <option value="">No supplier selected</option>
          ${App.db.suppliers.map(s => `<option value="${s.id}">${escapeHTML(s.name)}</option>`).join("")}
        </select>
      </div>

      <button class="btn green full">Add Stock</button>
    </form>
  `);
}

function saveAddedStock(event, id) {
  event.preventDefault();

  const p = App.db.products.find(x => x.id === id);
  const qty = Number(document.getElementById("stockQuantity").value);

  if (!p || qty <= 0) return;

  p.quantity += qty;
  p.lastStockInAt = nowISO();

  App.db.purchases.push({
    id: uid("PUR"),
    productId: p.id,
    quantity: qty,
    supplierId: document.getElementById("stockSupplier").value || null,
    date: nowISO()
  });

  addActivity(`New stock received: ${qty} × ${p.name}`);
  saveDB();
  closeModal();
  toast("Stock added successfully.");
  renderApplication();
}

/* =========================
   SCANNER
   ========================= */

function scannerPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Barcode / QR Scanner</h1>
        <div class="muted">
          Scan a product barcode or QR code with the phone camera.
        </div>
      </div>
    </div>

    <div class="card scanner-box">
      <div id="reader"></div>

      <div id="scanResult" class="notice">
        Scanner is ready. Tap Start Scanner and allow camera access.
      </div>

      <div class="toolbar">
        <button class="btn" onclick="startScanner()">Start Scanner</button>
        <button class="btn secondary" onclick="stopScanner()">Stop Scanner</button>
      </div>
    </div>
  `;
}

function startScanner() {
  if (typeof Html5Qrcode === "undefined") {
    toast("The scanner library has not loaded yet. Check your internet connection.", "error");
    return;
  }

  if (App.scannerRunning) return;

  App.scanner = new Html5Qrcode("reader");

  App.scanner.start(
    { facingMode: { ideal: "environment" } },
    {
      fps: 10,
      qrbox: { width: 280, height: 200 }
    },
    decodedText => {
      handleScannedCode(decodedText);
    },
    () => {}
  ).then(() => {
    App.scannerRunning = true;
    toast("Scanner started.");
  }).catch(error => {
    console.error(error);
    toast("Camera could not start. Allow camera permission and use the HTTPS GitHub Pages URL.", "error");
  });
}

function stopScanner() {
  if (!App.scanner) return;

  App.scanner.stop().then(() => {
    App.scanner.clear();
    App.scanner = null;
    App.scannerRunning = false;
  }).catch(() => {
    App.scanner = null;
    App.scannerRunning = false;
  });
}

function handleScannedCode(code) {
  const result = document.getElementById("scanResult");
  if (!result) return;

  const value = String(code).trim();
  const product = App.db.products.find(p => p.code === value);

  if (!product) {
    result.innerHTML = `
      <strong>Product not found</strong><br>
      Scanned code: ${escapeHTML(value)}<br><br>
      <button class="btn" onclick="createProductFromScan('${encodeURIComponent(value)}')">
        Create Product
      </button>
    `;
    return;
  }

  result.innerHTML = `
    <strong>${escapeHTML(product.name)}</strong><br>
    Barcode / QR: ${escapeHTML(product.code)}<br>
    Stock: ${product.quantity}<br>
    Selling price: ${money(product.sellPrice)}<br><br>

    <button class="btn green" onclick="addScannedProductToCart('${product.id}')">
      Add to Sale
    </button>
  `;
}

function createProductFromScan(encodedCode) {
  const code = decodeURIComponent(encodedCode);

  openModal(`
    <div class="modal-head">
      <h2>Create Product From Scan</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveScannedProduct(event,'${encodeURIComponent(code)}')">
      <div class="notice">Scanned code: <strong>${escapeHTML(code)}</strong></div>

      <div class="field">
        <label>Product Name</label>
        <input id="scanProductName" required>
      </div>

      <div class="field">
        <label>Buying Price</label>
        <input id="scanBuy" type="number" min="0" step="0.01" required>
      </div>

      <div class="field">
        <label>Selling Price</label>
        <input id="scanSell" type="number" min="0" step="0.01" required>
      </div>

      <div class="field">
        <label>Opening Quantity</label>
        <input id="scanQty" type="number" min="0" required>
      </div>

      <button class="btn full">Create Product</button>
    </form>
  `);
}

function saveScannedProduct(event, encodedCode) {
  event.preventDefault();

  const code = decodeURIComponent(encodedCode);

  const product = {
    id: uid("PRD"),
    name: document.getElementById("scanProductName").value.trim(),
    code,
    sku: "",
    buyPrice: Number(document.getElementById("scanBuy").value),
    sellPrice: Number(document.getElementById("scanSell").value),
    quantity: Number(document.getElementById("scanQty").value),
    minimumStock: 5,
    branchId: App.db.branches[0]?.id,
    createdAt: nowISO(),
    lastStockInAt: nowISO(),
    lastSoldAt: null
  };

  App.db.products.push(product);
  addActivity(`Product created from scan: ${product.name}`);
  saveDB();
  closeModal();
  toast("Product created from scanned code.");
  renderApplication();
}

function addScannedProductToCart(productId) {
  App.db.cart ||= [];

  const p = App.db.products.find(x => x.id === productId);
  if (!p) return;

  if (p.quantity <= 0) {
    toast("This product is out of stock.", "error");
    return;
  }

  const item = App.db.cart.find(x => x.productId === p.id);

  if (item) {
    if (item.quantity >= p.quantity) {
      toast("You cannot sell more than available stock.", "error");
      return;
    }
    item.quantity++;
  } else {
    App.db.cart.push({
      productId: p.id,
      name: p.name,
      quantity: 1,
      price: p.sellPrice
    });
  }

  saveDB();
  navigate("pos");
}

/* =========================
   POS / SALES
   ========================= */

function posPage() {
  App.db.cart ||= [];

  const total = App.db.cart.reduce((sum, x) => sum + x.quantity * x.price, 0);

  return `
    <div class="page-head">
      <div>
        <h1>Sales / POS</h1>
        <div class="muted">Scan or enter product codes to make a sale.</div>
      </div>
      <button class="btn secondary" onclick="navigate('scanner')">Open Scanner</button>
    </div>

    <div class="pos-grid">
      <div class="card">
        <h3>Add Product</h3>

        <div class="field">
          <label>Barcode / QR Identifier</label>
          <input id="posCode" placeholder="Scan with scanner or type code"
            onkeydown="if(event.key==='Enter')addPOSCode()">
        </div>

        <div class="toolbar">
          <button class="btn" onclick="addPOSCode()">Add Product</button>
          <button class="btn secondary" onclick="navigate('scanner')">Scan Camera</button>
        </div>

        <h3>Current Sale</h3>

        ${App.db.cart.length
          ? App.db.cart.map(cartRow).join("")
          : `<div class="empty">No products in the current sale.</div>`}
      </div>

      <div class="card">
        <h3>Sale Summary</h3>

        <div class="field">
          <label>Customer (optional)</label>
          <select id="saleCustomer">
            <option value="">Walk-in customer</option>
            ${App.db.customers.map(c => `
              <option value="${c.id}">${escapeHTML(c.name)} - ${escapeHTML(c.phone)}</option>
            `).join("")}
          </select>
        </div>

        <div class="field">
          <label>Payment Method</label>
          <select id="salePayment">
            <option>M-Pesa</option>
            <option>Cash</option>
            <option>Card</option>
            <option>Other</option>
          </select>
        </div>

        <div class="total-row">
          <span>Total</span>
          <span>${money(total)}</span>
        </div>

        <div class="toolbar">
          <button class="btn green full" onclick="completeSale()">Complete Sale & Generate Receipt</button>
          <button class="btn secondary full" onclick="clearCart()">Clear Sale</button>
        </div>
      </div>
    </div>
  `;
}

function cartRow(item) {
  return `
    <div class="cart-row">
      <div>
        <strong>${escapeHTML(item.name)}</strong><br>
        <small class="muted">${money(item.price)} each</small>
      </div>

      <div class="cart-actions">
        <button class="btn small secondary" onclick="changeCartQty('${item.productId}',-1)">−</button>
        <span class="qty">${item.quantity}</span>
        <button class="btn small secondary" onclick="changeCartQty('${item.productId}',1)">+</button>
        <button class="btn small red" onclick="removeFromCart('${item.productId}')">Remove</button>
      </div>
    </div>
  `;
}

function addPOSCode() {
  const input = document.getElementById("posCode");
  if (!input) return;

  const code = input.value.trim();
  if (!code) return;

  const product = App.db.products.find(p => p.code.toLowerCase() === code.toLowerCase());

  if (!product) {
    toast("Product barcode/QR identifier was not found.", "error");
    return;
  }

  if (product.quantity <= 0) {
    toast("Product is out of stock.", "error");
    return;
  }

  App.db.cart ||= [];

  const existing = App.db.cart.find(x => x.productId === product.id);

  if (existing) {
    if (existing.quantity >= product.quantity) {
      toast("Not enough stock.", "error");
      return;
    }
    existing.quantity++;
  } else {
    App.db.cart.push({
      productId: product.id,
      name: product.name,
      quantity: 1,
      price: product.sellPrice
    });
  }

  saveDB();
  renderApplication();
}

function changeCartQty(productId, amount) {
  const item = App.db.cart.find(x => x.productId === productId);
  const product = App.db.products.find(x => x.id === productId);

  if (!item || !product) return;

  const next = item.quantity + amount;

  if (next <= 0) {
    removeFromCart(productId);
    return;
  }

  if (next > product.quantity) {
    toast("Quantity cannot exceed available stock.", "error");
    return;
  }

  item.quantity = next;
  saveDB();
  renderApplication();
}

function removeFromCart(productId) {
  App.db.cart = App.db.cart.filter(x => x.productId !== productId);
  saveDB();
  renderApplication();
}

function clearCart() {
  App.db.cart = [];
  saveDB();
  renderApplication();
}

function completeSale() {
  const cart = App.db.cart || [];

  if (!cart.length) {
    toast("Add at least one product before completing the sale.", "error");
    return;
  }

  for (const item of cart) {
    const product = App.db.products.find(p => p.id === item.productId);

    if (!product || product.quantity < item.quantity) {
      toast(`Insufficient stock for ${item.name}.`, "error");
      return;
    }
  }

  const total = cart.reduce((sum, x) => sum + x.quantity * x.price, 0);
  const date = nowISO();

  const sale = {
    id: uid("SAL"),
    receiptNumber: uid("RCT"),
    date,
    branchId: App.db.branches[0]?.id || null,
    customerId: document.getElementById("saleCustomer")?.value || null,
    paymentMethod: document.getElementById("salePayment")?.value || "Cash",
    items: cart.map(x => ({...x})),
    total
  };

  cart.forEach(item => {
    const product = App.db.products.find(p => p.id === item.productId);
    product.quantity -= item.quantity;
    product.lastSoldAt = date;
  });

  App.db.sales.push(sale);
  App.db.cart = [];

  addActivity(`Sale completed: ${sale.receiptNumber} for ${money(total)}`);

  saveDB();
  App.lastReceipt = sale;

  toast("Sale completed successfully.");
  showReceiptModal(sale);
}

/* =========================
   RECEIPTS
   ========================= */

function receiptHTML(sale) {
  const business = App.db.business;
  const branch = getBranchName(sale.branchId);

  return `
    <div class="receipt">
      <h2>${escapeHTML(business.shopName)}</h2>
      <h3>SALES RECEIPT</h3>
      <p style="text-align:center">${escapeHTML(branch)}</p>

      <div class="receipt-line">
        <span>Receipt</span>
        <span>${escapeHTML(sale.receiptNumber)}</span>
      </div>

      <div class="receipt-line">
        <span>Date</span>
        <span>${new Date(sale.date).toLocaleString()}</span>
      </div>

      <div class="receipt-line">
        <span>Payment</span>
        <span>${escapeHTML(sale.paymentMethod)}</span>
      </div>

      <hr>

      ${sale.items.map(item => `
        <div class="receipt-line">
          <span>${escapeHTML(item.name)} × ${item.quantity}</span>
          <span>${money(item.quantity * item.price)}</span>
        </div>
      `).join("")}

      <hr>

      <div class="receipt-line">
        <strong>TOTAL</strong>
        <strong>${money(sale.total)}</strong>
      </div>

      <p style="text-align:center;margin-top:20px">
        Thank you for your business.
      </p>
    </div>
  `;
}

function showReceiptModal(sale) {
  openModal(`
    <div class="modal-head no-print">
      <h2>Receipt Generated</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <div id="receiptPrintArea" class="print-area">
      ${receiptHTML(sale)}
    </div>

    <div class="toolbar no-print">
      <button class="btn" onclick="printReceipt('${sale.id}')">Print Receipt</button>
      <button class="btn secondary" onclick="closeModal();navigate('reports')">View Reports</button>
    </div>
  `);
}

function printReceipt(saleId) {
  const sale = App.db.sales.find(s => s.id === saleId);
  if (!sale) return;

  const content = receiptHTML(sale);

  const win = window.open("", "_blank", "width=500,height=700");

  if (!win) {
    toast("Popup blocked. Allow popups to print the receipt.", "error");
    return;
  }

  win.document.write(`
    <!doctype html>
    <html>
    <head>
      <title>Receipt ${escapeHTML(sale.receiptNumber)}</title>
      <style>
        body{font-family:Arial,sans-serif;padding:20px}
        .receipt{width:360px;max-width:100%;margin:auto}
        h2,h3{text-align:center}
        .receipt-line{display:flex;justify-content:space-between;gap:10px;margin:7px 0}
        hr{border:0;border-top:1px dashed #999;margin:12px 0}
      </style>
    </head>
    <body>${content}</body>
    </html>
  `);

  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 250);
}

/* =========================
   CUSTOMERS
   ========================= */

function customersPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Customers</h1>
        <div class="muted">Customer records and purchase history.</div>
      </div>
      <button class="btn" onclick="addCustomer()">Add Customer</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr><th>Name</th><th>Phone</th><th>Purchases</th><th>Total Spent</th></tr>
        </thead>
        <tbody>
          ${App.db.customers.length ? App.db.customers.map(c => {
            const sales = App.db.sales.filter(s => s.customerId === c.id);
            const total = sales.reduce((sum,s) => sum+s.total,0);
            return `
              <tr>
                <td>${escapeHTML(c.name)}</td>
                <td>${escapeHTML(c.phone)}</td>
                <td>${sales.length}</td>
                <td>${money(total)}</td>
              </tr>
            `;
          }).join("") : `<tr><td colspan="4"><div class="empty">No customers yet.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function addCustomer() {
  openModal(`
    <div class="modal-head">
      <h2>Add Customer</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveCustomer(event)">
      <div class="field">
        <label>Customer Name</label>
        <input id="customerName" required>
      </div>
      <div class="field">
        <label>Phone Number</label>
        <input id="customerPhone">
      </div>
      <button class="btn full">Save Customer</button>
    </form>
  `);
}

function saveCustomer(event) {
  event.preventDefault();

  const customer = {
    id: uid("CUS"),
    name: document.getElementById("customerName").value.trim(),
    phone: document.getElementById("customerPhone").value.trim(),
    createdAt: nowISO()
  };

  App.db.customers.push(customer);
  addActivity(`Customer added: ${customer.name}`);
  saveDB();
  closeModal();
  toast("Customer added.");
  renderApplication();
}

/* =========================
   SUPPLIERS
   ========================= */

function suppliersPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Suppliers</h1>
        <div class="muted">Manage suppliers for new stock purchases.</div>
      </div>
      <button class="btn" onclick="addSupplier()">Add Supplier</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Phone</th><th>Email</th></tr></thead>
        <tbody>
          ${App.db.suppliers.length ? App.db.suppliers.map(s => `
            <tr>
              <td>${escapeHTML(s.name)}</td>
              <td>${escapeHTML(s.phone)}</td>
              <td>${escapeHTML(s.email)}</td>
            </tr>
          `).join("") : `<tr><td colspan="3"><div class="empty">No suppliers yet.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function addSupplier() {
  openModal(`
    <div class="modal-head">
      <h2>Add Supplier</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveSupplier(event)">
      <div class="field"><label>Supplier Name</label><input id="supplierName" required></div>
      <div class="field"><label>Phone</label><input id="supplierPhone"></div>
      <div class="field"><label>Email</label><input id="supplierEmail" type="email"></div>
      <button class="btn full">Save Supplier</button>
    </form>
  `);
}

function saveSupplier(event) {
  event.preventDefault();

  const supplier = {
    id: uid("SUP"),
    name: document.getElementById("supplierName").value.trim(),
    phone: document.getElementById("supplierPhone").value.trim(),
    email: document.getElementById("supplierEmail").value.trim(),
    createdAt: nowISO()
  };

  App.db.suppliers.push(supplier);
  addActivity(`Supplier added: ${supplier.name}`);
  saveDB();
  closeModal();
  toast("Supplier added.");
  renderApplication();
}

/* =========================
   PURCHASES / NEW STOCK
   ========================= */

function purchasesPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Purchases / New Stock</h1>
        <div class="muted">Record incoming stock from suppliers.</div>
      </div>
      <button class="btn" onclick="recordPurchase()">Record New Stock</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr><th>Date</th><th>Product</th><th>Quantity</th><th>Supplier</th></tr>
        </thead>
        <tbody>
          ${App.db.purchases.length ? App.db.purchases.slice().reverse().map(p => {
            const product = App.db.products.find(x => x.id === p.productId);
            const supplier = App.db.suppliers.find(x => x.id === p.supplierId);
            return `
              <tr>
                <td>${new Date(p.date).toLocaleString()}</td>
                <td>${escapeHTML(product?.name || "Deleted product")}</td>
                <td>${p.quantity}</td>
                <td>${escapeHTML(supplier?.name || "Not specified")}</td>
              </tr>
            `;
          }).join("") : `<tr><td colspan="4"><div class="empty">No stock purchases recorded.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function recordPurchase() {
  if (!App.db.products.length) {
    toast("Create a product first.", "error");
    return;
  }

  openModal(`
    <div class="modal-head">
      <h2>Record New Stock</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="savePurchase(event)">
      <div class="field">
        <label>Product</label>
        <select id="purchaseProduct" required>
          ${App.db.products.map(p => `
            <option value="${p.id}">${escapeHTML(p.name)} — ${escapeHTML(p.code)}</option>
          `).join("")}
        </select>
      </div>

      <div class="field">
        <label>Quantity Received</label>
        <input id="purchaseQty" type="number" min="1" required>
      </div>

      <div class="field">
        <label>Supplier</label>
        <select id="purchaseSupplier">
          <option value="">Not specified</option>
          ${App.db.suppliers.map(s => `<option value="${s.id}">${escapeHTML(s.name)}</option>`).join("")}
        </select>
      </div>

      <button class="btn green full">Add Stock</button>
    </form>
  `);
}

function savePurchase(event) {
  event.preventDefault();

  const product = App.db.products.find(p => p.id === document.getElementById("purchaseProduct").value);
  const quantity = Number(document.getElementById("purchaseQty").value);
  const supplierId = document.getElementById("purchaseSupplier").value || null;

  if (!product || quantity <= 0) return;

  product.quantity += quantity;
  product.lastStockInAt = nowISO();

  App.db.purchases.push({
    id: uid("PUR"),
    productId: product.id,
    quantity,
    supplierId,
    date: nowISO()
  });

  addActivity(`New stock recorded: ${quantity} × ${product.name}`);
  saveDB();
  closeModal();
  toast("New stock recorded successfully.");
  renderApplication();
}

/* =========================
   TRANSFERS
   ========================= */

function transfersPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Stock Transfers</h1>
        <div class="muted">Transfer stock between branches with a reference.</div>
      </div>
      <button class="btn" onclick="createTransfer()">New Transfer</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr>
            <th>Transfer No.</th>
            <th>Date</th>
            <th>From</th>
            <th>To</th>
            <th>Items</th>
            <th>Status</th>
            <th>Receipt</th>
          </tr>
        </thead>
        <tbody>
          ${App.db.transfers.length ? App.db.transfers.slice().reverse().map(t => `
            <tr>
              <td>${escapeHTML(t.reference)}</td>
              <td>${new Date(t.date).toLocaleString()}</td>
              <td>${escapeHTML(getBranchName(t.fromBranchId))}</td>
              <td>${escapeHTML(getBranchName(t.toBranchId))}</td>
              <td>${t.items.reduce((sum,x)=>sum+x.quantity,0)}</td>
              <td><span class="badge green">${escapeHTML(t.status)}</span></td>
              <td><button class="btn small" onclick="printTransfer('${t.id}')">Print</button></td>
            </tr>
          `).join("") : `<tr><td colspan="7"><div class="empty">No stock transfers recorded.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function createTransfer() {
  if (App.db.branches.length < 2) {
    toast("Create at least two branches before making a stock transfer.", "error");
    return;
  }

  if (!App.db.products.length) {
    toast("Create products before making a stock transfer.", "error");
    return;
  }

  openModal(`
    <div class="modal-head">
      <h2>New Stock Transfer</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveTransfer(event)">
      <div class="two-col">
        <div class="field">
          <label>From Branch</label>
          <select id="transferFrom" required>
            ${App.db.branches.map(b => `<option value="${b.id}">${escapeHTML(b.name)}</option>`).join("")}
          </select>
        </div>

        <div class="field">
          <label>To Branch</label>
          <select id="transferTo" required>
            ${App.db.branches.map(b => `<option value="${b.id}">${escapeHTML(b.name)}</option>`).join("")}
          </select>
        </div>
      </div>

      <div class="field">
        <label>Product</label>
        <select id="transferProduct" required>
          ${App.db.products.map(p => `
            <option value="${p.id}">${escapeHTML(p.name)} — Stock ${p.quantity}</option>
          `).join("")}
        </select>
      </div>

      <div class="field">
        <label>Quantity</label>
        <input id="transferQty" type="number" min="1" required>
      </div>

      <button class="btn full">Complete Transfer</button>
    </form>
  `);
}

function saveTransfer(event) {
  event.preventDefault();

  const from = document.getElementById("transferFrom").value;
  const to = document.getElementById("transferTo").value;
  const product = App.db.products.find(p => p.id === document.getElementById("transferProduct").value);
  const quantity = Number(document.getElementById("transferQty").value);

  if (from === to) {
    toast("From and To branches must be different.", "error");
    return;
  }

  if (!product || quantity <= 0) return;

  if (product.quantity < quantity) {
    toast("Not enough stock to transfer.", "error");
    return;
  }

  product.quantity -= quantity;

  const transfer = {
    id: uid("TRF"),
    reference: uid("TRANSFER"),
    date: nowISO(),
    fromBranchId: from,
    toBranchId: to,
    status: "COMPLETED",
    items: [{
      productId: product.id,
      name: product.name,
      quantity
    }]
  };

  App.db.transfers.push(transfer);
  addActivity(`Stock transfer completed: ${transfer.reference}`);
  saveDB();
  closeModal();
  toast("Stock transfer completed.");
  renderApplication();
}

function printTransfer(id) {
  const transfer = App.db.transfers.find(t => t.id === id);
  if (!transfer) return;

  const html = `
    <div class="receipt">
      <h2>${escapeHTML(App.db.business.shopName)}</h2>
      <h3>STOCK TRANSFER RECEIPT</h3>
      <div class="receipt-line"><span>Transfer</span><span>${escapeHTML(transfer.reference)}</span></div>
      <div class="receipt-line"><span>Date</span><span>${new Date(transfer.date).toLocaleString()}</span></div>
      <div class="receipt-line"><span>From</span><span>${escapeHTML(getBranchName(transfer.fromBranchId))}</span></div>
      <div class="receipt-line"><span>To</span><span>${escapeHTML(getBranchName(transfer.toBranchId))}</span></div>
      <hr>
      ${transfer.items.map(i => `
        <div class="receipt-line">
          <span>${escapeHTML(i.name)}</span>
          <span>${i.quantity}</span>
        </div>
      `).join("")}
      <hr>
      <div class="receipt-line"><strong>Status</strong><strong>${escapeHTML(transfer.status)}</strong></div>
    </div>
  `;

  const win = window.open("", "_blank", "width=500,height=700");
  if (!win) {
    toast("Popup blocked. Allow popups to print.", "error");
    return;
  }

  win.document.write(`
    <html><head><title>Transfer ${escapeHTML(transfer.reference)}</title>
    <style>body{font-family:Arial;padding:20px}.receipt{width:360px;max-width:100%;margin:auto}.receipt-line{display:flex;justify-content:space-between;margin:7px 0}h2,h3{text-align:center}hr{border:0;border-top:1px dashed #999}</style>
    </head><body>${html}</body></html>
  `);

  win.document.close();
  setTimeout(() => win.print(), 250);
}

/* =========================
   BRANCHES
   ========================= */

function branchesPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Branches</h1>
        <div class="muted">Manage locations for your business.</div>
      </div>
      <button class="btn" onclick="addBranch()">Add Branch</button>
    </div>

    <div class="grid-3">
      ${App.db.branches.map(b => `
        <div class="card">
          <h3>${escapeHTML(b.name)}</h3>
          <p class="muted">${escapeHTML(b.address || "No address entered")}</p>
          <p>${escapeHTML(b.phone || "")}</p>
          <span class="badge green">Active</span>
        </div>
      `).join("")}
    </div>
  `;
}

function addBranch() {
  openModal(`
    <div class="modal-head">
      <h2>Add Branch</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveBranch(event)">
      <div class="field"><label>Branch Name</label><input id="branchName" required></div>
      <div class="field"><label>Phone</label><input id="branchPhone"></div>
      <div class="field"><label>Address</label><textarea id="branchAddress"></textarea></div>
      <button class="btn full">Create Branch</button>
    </form>
  `);
}

function saveBranch(event) {
  event.preventDefault();

  const branch = {
    id: uid("BR"),
    name: document.getElementById("branchName").value.trim(),
    phone: document.getElementById("branchPhone").value.trim(),
    address: document.getElementById("branchAddress").value.trim(),
    createdAt: nowISO()
  };

  App.db.branches.push(branch);
  addActivity(`Branch created: ${branch.name}`);
  saveDB();
  closeModal();
  toast("Branch created.");
  renderApplication();
}

/* =========================
   EMPLOYEES
   ========================= */

function employeesPage() {
  return `
    <div class="page-head">
      <div>
        <h1>Employees</h1>
        <div class="muted">Basic employee records for this testing version.</div>
      </div>
      <button class="btn" onclick="addEmployee()">Add Employee</button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Phone</th><th>Role</th><th>Branch</th></tr></thead>
        <tbody>
          ${App.db.employees.length ? App.db.employees.map(e => `
            <tr>
              <td>${escapeHTML(e.name)}</td>
              <td>${escapeHTML(e.phone)}</td>
              <td>${escapeHTML(e.role)}</td>
              <td>${escapeHTML(getBranchName(e.branchId))}</td>
            </tr>
          `).join("") : `<tr><td colspan="4"><div class="empty">No employees yet.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function addEmployee() {
  openModal(`
    <div class="modal-head">
      <h2>Add Employee</h2>
      <button class="close" onclick="closeModal()">Close</button>
    </div>

    <form onsubmit="saveEmployee(event)">
      <div class="field"><label>Name</label><input id="employeeName" required></div>
      <div class="field"><label>Phone</label><input id="employeePhone"></div>
      <div class="field"><label>Role</label>
        <select id="employeeRole"><option>Cashier</option><option>Manager</option><option>Storekeeper</option><option>Sales</option></select>
      </div>
      <div class="field"><label>Branch</label>
        <select id="employeeBranch">${App.db.branches.map(b=>`<option value="${b.id}">${escapeHTML(b.name)}</option>`).join("")}</select>
      </div>
      <button class="btn full">Save Employee</button>
    </form>
  `);
}

function saveEmployee(event) {
  event.preventDefault();

  const employee = {
    id: uid("EMP"),
    name: document.getElementById("employeeName").value.trim(),
    phone: document.getElementById("employeePhone").value.trim(),
    role: document.getElementById("employeeRole").value,
    branchId: document.getElementById("employeeBranch").value,
    createdAt: nowISO()
  };

  App.db.employees.push(employee);
  addActivity(`Employee added: ${employee.name}`);
  saveDB();
  closeModal();
  toast("Employee added.");
  renderApplication();
}

/* =========================
   EXPENSES
   ========================= */

function expensesPage() {
  const total = App.db.expenses.reduce((sum,e)=>sum+e.amount,0);

  return `
    <div class="page-head">
      <div>
        <h1>Expenses</h1>
        <div class="muted">Record business expenses.</div>
      </div>
      <button class="btn" onclick="addExpense()">Add Expense</button>
    </div>

    <div class="grid">
      ${metricCard("Total Expenses", money(total))}
      ${metricCard("Expense Records", App.db.expenses.length)}
    </div>

    <div class="card table-wrap" style="margin-top:15px">
      <table>
        <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th></tr></thead>
        <tbody>
          ${App.db.expenses.length ? App.db.expenses.slice().reverse().map(e=>`
            <tr><td>${new Date(e.date).toLocaleString()}</td><td>${escapeHTML(e.description)}</td><td>${escapeHTML(e.category)}</td><td>${money(e.amount)}</td></tr>
          `).join("") : `<tr><td colspan="4"><div class="empty">No expenses recorded.</div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function addExpense() {
  openModal(`
    <div class="modal-head"><h2>Add Expense</h2><button class="close" onclick="closeModal()">Close</button></div>
    <form onsubmit="saveExpense(event)">
      <div class="field"><label>Description</label><input id="expenseDescription" required></div>
      <div class="field"><label>Category</label><select id="expenseCategory"><option>Rent</option><option>Transport</option><option>Salary</option><option>Utilities</option><option>Other</option></select></div>
      <div class="field"><label>Amount</label><input id="expenseAmount" type="number" min="0" step="0.01" required></div>
      <button class="btn full">Save Expense</button>
    </form>
  `);
}

function saveExpense(event) {
  event.preventDefault();

  const expense = {
    id: uid("EXP"),
    description: document.getElementById("expenseDescription").value.trim(),
    category: document.getElementById("expenseCategory").value,
    amount: Number(document.getElementById("expenseAmount").value),
    date: nowISO()
  };

  App.db.expenses.push(expense);
  addActivity(`Expense recorded: ${expense.description}`);
  saveDB();
  closeModal();
  toast("Expense saved.");
  renderApplication();
}

/* =========================
   REPORTS / PRINTING
   ========================= */

function reportsPage() {
  const revenue = App.db.sales.reduce((sum,s)=>sum+s.total,0);
  const expenses = App.db.expenses.reduce((sum,e)=>sum+e.amount,0);

  return `
    <div class="page-head">
      <div>
        <h1>Reports & Printing</h1>
        <div class="muted">Daily, monthly, yearly sales and transfer reports.</div>
      </div>
    </div>

    <div class="grid">
      ${metricCard("All Sales Revenue", money(revenue))}
      ${metricCard("All Expenses", money(expenses))}
      ${metricCard("Estimated Net", money(revenue-expenses))}
      ${metricCard("Transfers", App.db.transfers.length)}
    </div>

    <div class="card" style="margin-top:15px">
      <h3>Sales Reports</h3>
      <div class="toolbar">
        <button class="btn" onclick="printPeriodReport('daily')">Print Daily</button>
        <button class="btn" onclick="printPeriodReport('monthly')">Print Monthly</button>
        <button class="btn" onclick="printPeriodReport('yearly')">Print Yearly</button>
        <button class="btn secondary" onclick="printAllSales()">Print All Sales</button>
      </div>
    </div>

    <div class="card" style="margin-top:15px">
      <h3>Inventory Reports</h3>
      <div class="toolbar">
        <button class="btn secondary" onclick="printInventoryReport()">Print Current Stock</button>
        <button class="btn secondary" onclick="printDeadStockReport()">Print Dead Stock</button>
        <button class="btn secondary" onclick="printTransferReport()">Print Stock Transfers</button>
      </div>
    </div>

    ${App.lastReceipt ? `<div class="card" style="margin-top:15px">${receiptHTML(App.lastReceipt)}</div>` : ""}
  `;
}

function periodStart(period) {
  const d = new Date();

  if (period === "daily") {
    d.setHours(0,0,0,0);
  } else if (period === "monthly") {
    d.setDate(1);
    d.setHours(0,0,0,0);
  } else if (period === "yearly") {
    d.setMonth(0,1);
    d.setHours(0,0,0,0);
  }

  return d;
}

function printPeriodReport(period) {
  const start = periodStart(period);
  const sales = App.db.sales.filter(s => new Date(s.date) >= start);
  const revenue = sales.reduce((sum,s)=>sum+s.total,0);
  const title = `${period[0].toUpperCase()+period.slice(1)} Sales Report`;

  printDocument(`
    <h2>${escapeHTML(App.db.business.shopName)}</h2>
    <h3>${title}</h3>
    <p>From: ${start.toLocaleString()}</p>
    <p>Transactions: <strong>${sales.length}</strong></p>
    <p>Revenue: <strong>${money(revenue)}</strong></p>
    <table>
      <thead><tr><th>Receipt</th><th>Date</th><th>Payment</th><th>Total</th></tr></thead>
      <tbody>
        ${sales.map(s=>`
          <tr>
            <td>${escapeHTML(s.receiptNumber)}</td>
            <td>${new Date(s.date).toLocaleString()}</td>
            <td>${escapeHTML(s.paymentMethod)}</td>
            <td>${money(s.total)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `, title);
}

function printAllSales() {
  const revenue = App.db.sales.reduce((sum,s)=>sum+s.total,0);

  printDocument(`
    <h2>${escapeHTML(App.db.business.shopName)}</h2>
    <h3>All Sales Report</h3>
    <p>Transactions: <strong>${App.db.sales.length}</strong></p>
    <p>Total revenue: <strong>${money(revenue)}</strong></p>
    <table>
      <thead><tr><th>Receipt</th><th>Date</th><th>Branch</th><th>Total</th></tr></thead>
      <tbody>
        ${App.db.sales.map(s=>`
          <tr><td>${escapeHTML(s.receiptNumber)}</td><td>${new Date(s.date).toLocaleString()}</td><td>${escapeHTML(getBranchName(s.branchId))}</td><td>${money(s.total)}</td></tr>
        `).join("")}
      </tbody>
    </table>
  `, "All Sales");
}

function printInventoryReport() {
  const value = App.db.products.reduce((sum,p)=>sum+p.quantity*p.buyPrice,0);

  printDocument(`
    <h2>${escapeHTML(App.db.business.shopName)}</h2>
    <h3>Current Inventory Report</h3>
    <p>Total stock value: <strong>${money(value)}</strong></p>
    <table>
      <thead><tr><th>Product</th><th>Code</th><th>Quantity</th><th>Buy Price</th><th>Value</th></tr></thead>
      <tbody>
        ${App.db.products.map(p=>`
          <tr><td>${escapeHTML(p.name)}</td><td>${escapeHTML(p.code)}</td><td>${p.quantity}</td><td>${money(p.buyPrice)}</td><td>${money(p.quantity*p.buyPrice)}</td></tr>
        `).join("")}
      </tbody>
    </table>
  `, "Current Inventory");
}

function calculateDeadStock() {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 30);

  return App.db.products.filter(p => {
    if (p.quantity <= 0) return false;
    if (!p.lastSoldAt) return new Date(p.createdAt) < cutoff;
    return new Date(p.lastSoldAt) < cutoff;
  });
}

function printDeadStockReport() {
  const dead = calculateDeadStock();
  const value = dead.reduce((sum,p)=>sum+p.quantity*p.buyPrice,0);

  printDocument(`
    <h2>${escapeHTML(App.db.business.shopName)}</h2>
    <h3>Dead / Slow Stock Report</h3>
    <p>Definition in this demo: no recorded sale for at least 30 days.</p>
    <p>Items: <strong>${dead.length}</strong></p>
    <p>Stock value tied up: <strong>${money(value)}</strong></p>
    <table>
      <thead><tr><th>Product</th><th>Quantity</th><th>Last Sale</th><th>Value</th></tr></thead>
      <tbody>
        ${dead.map(p=>`
          <tr>
            <td>${escapeHTML(p.name)}</td>
            <td>${p.quantity}</td>
            <td>${p.lastSoldAt ? new Date(p.lastSoldAt).toLocaleString() : "Never"}</td>
            <td>${money(p.quantity*p.buyPrice)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `, "Dead Stock");
}

function printTransferReport() {
  printDocument(`
    <h2>${escapeHTML(App.db.business.shopName)}</h2>
    <h3>Stock Transfer Report</h3>
    <table>
      <thead><tr><th>Reference</th><th>Date</th><th>From</th><th>To</th><th>Items</th></tr></thead>
      <tbody>
        ${App.db.transfers.map(t=>`
          <tr>
            <td>${escapeHTML(t.reference)}</td>
            <td>${new Date(t.date).toLocaleString()}</td>
            <td>${escapeHTML(getBranchName(t.fromBranchId))}</td>
            <td>${escapeHTML(getBranchName(t.toBranchId))}</td>
            <td>${t.items.reduce((sum,x)=>sum+x.quantity,0)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `, "Stock Transfers");
}

function printDocument(body, title) {
  const win = window.open("", "_blank", "width=900,height=800");

  if (!win) {
    toast("Popup blocked. Allow popups to print reports.", "error");
    return;
  }

  win.document.write(`
    <!doctype html>
    <html>
    <head>
      <title>${escapeHTML(title)}</title>
      <style>
        body{font-family:Arial,sans-serif;padding:30px;color:#111}
        h2,h3{text-align:center}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th,td{border:1px solid #ccc;padding:8px;text-align:left}
        th{background:#f2f2f2}
      </style>
    </head>
    <body>${body}</body>
    </html>
  `);

  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 250);
}

/* =========================
   ACTIVITY
   ========================= */

function activityPage() {
  const rows = App.db.activity.slice().reverse();

  return `
    <div class="page-head">
      <div>
        <h1>Activity Log</h1>
        <div class="muted">Recorded actions in this browser demo.</div>
      </div>
    </div>

    <div class="card">
      ${rows.length ? rows.map(a => `
        <div class="cart-row">
          <span>${escapeHTML(a.text)}</span>
          <small class="muted">${new Date(a.at).toLocaleString()}</small>
        </div>
      `).join("") : `<div class="empty">No activity.</div>`}
    </div>

    <div class="footer-note">
      Vortex Business Management System — GitHub Pages testing edition.
    </div>
  `;
}

/* =========================
   MODALS
   ========================= */

function openModal(content) {
  closeModal();

  const el = document.createElement("div");
  el.id = "modalRoot";
  el.className = "modal-backdrop";
  el.innerHTML = `<div class="modal">${content}</div>`;

  document.body.appendChild(el);
}

function closeModal() {
  document.getElementById("modalRoot")?.remove();
}

/* =========================
   START
   ========================= */

window.addEventListener("beforeunload", () => {
  try { stopScanner(); } catch (_) {}
});

render();
